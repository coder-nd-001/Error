/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jsp.pract1;

import java.rmi.*;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            ServerIntf server = (ServerIntf) Naming.lookup("rmi://localhost/Server");

            System.out.print("Enter num1: ");
            int a = sc.nextInt();

            System.out.print("Enter num2: ");
            int b = sc.nextInt();

            System.out.println("Addition: " + server.addition(a, b));
            System.out.println("Subtraction: " + server.subtraction(a, b));
            System.out.println("Multiplication: " + server.multiplication(a, b));
            System.out.println("Division: " + server.division(a, b));
            System.out.println("Square: " + server.square(a));
            System.out.println("Square Root: " + server.squareroot(b));

            sc.nextLine(); // FIX: consume leftover newline

            System.out.print("Enter string 1: ");
            String str1 = sc.nextLine();

            System.out.print("Enter string 2: ");
            String str2 = sc.nextLine();

            System.out.println("Palindrome: " + server.palindrome(str1));
            System.out.println("Strings Equal: " + server.isequalstring(str1, str2));

        } catch (Exception e) {
            System.out.println("Client error: " + e);
        }

        sc.close();
    }
}
