import java.rmi.*;
import java.rmi.server.*;

public class ServerImpl extends UnicastRemoteObject implements ServerIntf {

    public ServerImpl() throws RemoteException {
        super();
    }

    public int addition(int a, int b) throws RemoteException {
        return a + b;
    }

    public int subtraction(int a, int b) throws RemoteException {
        return a - b;
    }

    public int multiplication(int a, int b) throws RemoteException {
        return a * b;
    }

    public double division(int a, int b) throws RemoteException {
        if (b == 0) {
            throw new RemoteException("Division by zero not allowed");
        }
        return (double) a / b;
    }

    public int square(int a) throws RemoteException {
        return a * a;
    }

    public double squareroot(int a) throws RemoteException {
        return Math.sqrt(a);
    }

    public boolean palindrome(String str) throws RemoteException {
        String reversed = new StringBuilder(str).reverse().toString();
        return str.equals(reversed);
    }

    public boolean isequalstring(String str1, String str2) throws RemoteException {
        return str1.equals(str2);
    }
}
