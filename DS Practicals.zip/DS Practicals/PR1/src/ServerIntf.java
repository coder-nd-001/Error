import java.rmi.*;

public interface ServerIntf extends Remote {

    int addition(int a, int b) throws RemoteException;

    int subtraction(int a, int b) throws RemoteException;

    int multiplication(int a, int b) throws RemoteException;

    double division(int a, int b) throws RemoteException;

    int square(int a) throws RemoteException;

    double squareroot(int a) throws RemoteException;

    boolean palindrome(String str) throws RemoteException;

    boolean isequalstring(String str1, String str2) throws RemoteException;
}
