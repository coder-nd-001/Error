/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jsp.pract1;

import java.rmi.*;
import java.rmi.registry.LocateRegistry;

public class Server {

    public static void main(String[] args) {
        try {
            
            LocateRegistry.createRegistry(1099); //if error remove this
            ServerImpl obj = new ServerImpl();

            Naming.rebind("rmi://localhost/Server", obj);

            System.out.println("Server started successfully...");
        } catch (Exception e) {
            System.out.println("Server error: " + e);
        }
    }
}

